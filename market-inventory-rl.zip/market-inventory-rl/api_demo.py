import requests

# List of example inputs
examples = [
    {"stock": 12, "day_of_week": 2, "mov_avg": 10},
    {"stock": 5, "day_of_week": 4, "mov_avg": 8},
    {"stock": 20, "day_of_week": 0, "mov_avg": 15}
]

# Call API and print outputs
print("RL Agent API Demo Results\n")
for i, data in enumerate(examples, start=1):
    response = requests.post("http://127.0.0.1:8080/predict", json=data)
    order_qty = response.json().get("order_qty")
    print(f"Example {i} - Input: {data} -> Agent Suggested Order: {order_qty}")
