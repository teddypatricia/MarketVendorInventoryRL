# train_and_eval.py
import pickle
import numpy as np
from env import MarketEnv
from q_learning import state_to_key

# load q-table
with open('models/q_table.pkl', 'rb') as f:
    Q = pickle.load(f)

env = MarketEnv()

def run_policy(episodes=100, days_per_episode=30):
    profits = []
    stockouts_total = 0
    for ep in range(episodes):
        state = env.reset()
        total_reward = 0
        for day in range(days_per_episode):
            s_key = state_to_key(state)
            action_vals = Q.get(s_key, np.zeros(env.max_order+1))
            a = int(np.argmax(action_vals))
            next_state, r, _, info = env.step(a)
            total_reward += r
            stockouts_total += info['unfulfilled']
            state = next_state
        profits.append(total_reward / days_per_episode)
    print('Average daily profit over runs:', np.mean(profits))
    print('Profit std:', np.std(profits))
    print('Stockouts (total units) over runs:', stockouts_total)

if __name__ == '__main__':
    run_policy()
