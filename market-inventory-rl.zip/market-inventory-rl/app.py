# app.py

from fastapi import FastAPI
import pickle
import numpy as np
from q_learning import state_to_key
from pydantic import BaseModel

class StateIn(BaseModel):
    stock: int
    day_of_week: int  # 0..6
    mov_avg: int

app = FastAPI()

with open('models/q_table.pkl', 'rb') as f:
    Q = pickle.load(f)

@app.post('/predict')
def predict(state: StateIn):
    s_key = state_to_key((state.stock, state.day_of_week, state.mov_avg))
    action_vals = Q.get(s_key, np.zeros(21))
    order_q = int(np.argmax(action_vals))
    return {'order_qty': order_q}
