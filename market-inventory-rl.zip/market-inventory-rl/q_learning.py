# q_learning.py
import random
import pickle
from collections import defaultdict
import numpy as np
from env import MarketEnv
import os

# helper to make states hashable
def state_to_key(state):
    # state is (stock, day_of_week, mov_avg)
    stock, dow, mov = state
    stock_bucket = stock // 2
    return (stock_bucket, dow, mov)

def train_qlearning(episodes=3000, days_per_episode=30,
                    alpha=0.1, gamma=0.99, eps_start=1.0, eps_end=0.05, eps_decay=0.995):

    env = MarketEnv()
    Q = defaultdict(lambda: np.zeros(env.max_order + 1))
    eps = eps_start

    for ep in range(1, episodes+1):
        state = env.reset()
        total_reward = 0
        for day in range(days_per_episode):
            s_key = state_to_key(state)
            # choose action
            if random.random() < eps:
                a = random.randint(0, env.max_order)
            else:
                a = int(np.argmax(Q[s_key]))
            next_state, r, done, info = env.step(a)
            ns_key = state_to_key(next_state)

            # Q update
            Q[s_key][a] += alpha * (r + gamma * np.max(Q[ns_key]) - Q[s_key][a])
            state = next_state
            total_reward += r

        # decay epsilon
        eps = max(eps_end, eps * eps_decay)

        if ep % 100 == 0 or ep == 1:
            avg_reward = total_reward / days_per_episode
            print(f"Episode {ep}/{episodes}  avg_reward (last ep) = {avg_reward:.2f}  eps={eps:.3f}")

    # --- SAFE SAVING SECTION (fixed) ---
    model_dir = os.path.join(os.getcwd(), "models")
    os.makedirs(model_dir, exist_ok=True)

    save_path = os.path.join(model_dir, "q_table.pkl")
    with open(save_path, "wb") as f:
        pickle.dump(dict(Q), f)

    print("Training complete, Q-table saved to", save_path)
    return Q


if __name__ == '__main__':
    train_qlearning()

