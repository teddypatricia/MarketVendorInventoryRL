# env.py
import numpy as np

class MarketEnv:
    """Simple market vendor environment.
    State: (stock, day_of_week, mov_avg)
    Action: integer order quantity (0..max_order)
    """

    def __init__(self, max_stock=100, max_order=20,
                 lam_weekday=12, lam_weekend=20,
                 price=1000, order_cost_per=600,
                 holding_cost_per=10, stockout_penalty_per=200,
                 mov_avg_len=3):
        self.max_stock = max_stock
        self.max_order = max_order
        self.lam_weekday = lam_weekday
        self.lam_weekend = lam_weekend
        self.price = price
        self.order_cost_per = order_cost_per
        self.holding_cost_per = holding_cost_per
        self.stockout_penalty_per = stockout_penalty_per
        self.mov_avg_len = mov_avg_len
        self.reset()

    def reset(self, init_stock=10):
        self.day = 0
        self.stock = init_stock
        self.past_demands = [self.lam_weekday] * self.mov_avg_len
        state = (self.stock, self.day % 7, int(np.mean(self.past_demands)))
        return state

    def _sample_demand(self):
        lam = self.lam_weekend if (self.day % 7) in (5,6) else self.lam_weekday
        return np.random.poisson(lam)

    def step(self, order_q):
        # apply order (arrives instantly for simplicity)
        order_q = int(max(0, min(self.max_order, order_q)))
        self.stock = min(self.max_stock, self.stock + order_q)

        demand = self._sample_demand()
        sold = min(self.stock, demand)
        unfulfilled = max(0, demand - sold)
        self.stock -= sold

        revenue = self.price * sold
        cost = self.order_cost_per * order_q
        holding_cost = self.holding_cost_per * self.stock
        stockout_penalty = self.stockout_penalty_per * unfulfilled

        reward = revenue - cost - holding_cost - stockout_penalty

        # update history
        self.past_demands.pop(0)
        self.past_demands.append(demand)

        self.day += 1
        state = (self.stock, self.day % 7, int(np.mean(self.past_demands)))
        done = False  # episodes managed externally (e.g., 30 steps)
        info = {"demand": demand, "sold": sold, "unfulfilled": unfulfilled}
        return state, reward, done, info
